-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2026. Ápr 15. 13:02
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `hidak`
--
CREATE DATABASE IF NOT EXISTS `hidak` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE `hidak`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `fuggohidak`
--

CREATE TABLE `fuggohidak` (
  `Helyezés` int(2) DEFAULT NULL,
  `Híd` varchar(30) DEFAULT NULL,
  `Hely` varchar(27) DEFAULT NULL,
  `Ország` varchar(18) DEFAULT NULL,
  `Hossz` int(4) DEFAULT NULL,
  `Év` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- A tábla adatainak kiíratása `fuggohidak`
--

INSERT INTO `fuggohidak` (`Helyezés`, `Híd`, `Hely`, `Ország`, `Hossz`, `Év`) VALUES
(1, '1915 Çanakkale híd', 'Dardanellák', 'Törökország', 2023, 2022),
(2, 'Akasi Kaikjó híd', 'Kóbe − Awaji', 'Japán', 1991, 1998),
(3, 'Xihoumen-híd', 'Zhoushan', 'Kína', 1650, 2008),
(4, 'Nagy-Bælt híd', 'Großer Belt', 'Dánia', 1624, 1998),
(5, 'Osman Gazi híd', 'Izmit-öböl', 'Törökország', 1550, 2016),
(6, 'I Szunsin híd', 'Joszu', 'Dél-Korea', 1545, 2012),
(7, 'Runyang-híd', 'Csencsiang − Jangcsou', 'Kína', 1490, 2005),
(8, 'Negyedik nankingi Jangce-híd', 'Nanking − Csiangszu', 'Kína', 1418, 2012),
(9, 'Humber híd', 'Barton-upon-Humber − Hessle', 'Egyesült Királyság', 1410, 1981),
(10, 'Vitéz Szelim szultán híd', 'Isztambul', 'Törökország', 1408, 2016),
(11, 'Jiangyin-híd', 'Jiangyin − Jingjiang', 'Kína', 1385, 1999),
(12, 'Tsing-Ma-híd', 'Tsing Yi − Ma Wan', 'Kína', 1377, 1997),
(13, 'Hardanger híd', 'Hordaland megye', 'Norvégia', 1310, 2013),
(14, 'Verrazano-Narrows híd', 'New York City', 'USA', 1298, 1964),
(15, 'Golden Gate híd', 'San Francisco − Sausalito', 'USA', 1280, 1937),
(16, 'Yangluo híd', 'Vuhan', 'Kína', 1280, 2007),
(17, 'Högakustenbrücke', 'Härnösand − Kramfors', 'Svédország', 1210, 1997),
(18, 'Longjiang-híd', 'Baoshan − Jünnan', 'Kína', 1196, 2016),
(19, 'Aizhai híd', 'Jishou − Hunan', 'Kína', 1176, 2012),
(20, 'Mackinac híd', 'Mackinaw City − St. Ignace', 'USA', 1158, 1957),
(21, 'Ulsan híd', 'Ulszan', 'Dél-Korea', 1150, 2015),
(22, 'Qingshui folyó hídja', 'Kujcsou', 'Kína', 1130, 2015),
(23, '(Déli) Huangpu híd', 'Kanton − Kuangtung', 'Kína', 1108, 2008),
(24, 'Déli Bisan-Seto-híd', 'Kōjima − Sakaide', 'Japán', 1100, 1988),
(25, 'Győzedelmes Mehmed szultán híd', 'Isztambul', 'Törökország', 1090, 1988),
(26, 'Baling folyó hídja', 'Guanling', 'Kína', 1088, 2009),
(27, 'Taizhou híd', 'Taizhou − Csiangszu', 'Kína', 1080, 2012),
(28, 'Ma\'anshan híd', 'Ma\'anshan − Anhuj', 'Kína', 1080, 2013),
(29, 'Július 15. vértanúinak hídja', 'Isztambul', 'Törökország', 1074, 1973),
(30, 'George Washington híd', 'Fort Lee − Manhattan', 'USA', 1067, 1931),
(31, 'Fuma híd', 'Wanzhou − Csungking', 'Kína', 1050, 2017),
(32, 'Harmadik Kurushima Kaikyo híd', 'Onomichi − Imabari', 'Japán', 1030, 1999),
(33, 'Második Kurushima Kaikyo híd', 'Onomichi − Imabari', 'Japán', 1020, 1999),
(34, 'Április 25. híd', 'Lisszabon − Almada', 'Portugália', 1013, 1966),
(35, 'Forth Road híd', 'Firth of Forth', 'Egyesült Királyság', 1006, 1964),
(36, 'Északi Bisan-Seto-híd', 'Kōjima − Sakaide', 'Japán', 990, 1988),
(37, 'Severn híd', 'Bristolkanal', 'Egyesült Királyság', 988, 1966),
(38, 'Yichang-híd', 'Yichang', 'Kína', 960, 1996),
(39, 'Shimotsui-Seto-híd', 'Kōjima − Sakaide', 'Japán', 940, 1988),
(40, 'Xiling-híd', 'Xiling', 'Kína', 900, 1996),
(41, 'Siduhe-híd', 'Yesanguan', 'Kína', 900, 2009),
(42, 'Humen-híd', 'Dongguan', 'Kína', 888, 1997),
(43, 'Cuntan híd', 'Csungking', 'Kína', 880, 2017),
(44, 'Naruto-híd', 'Awaji − Naruto', 'Japán', 876, 1985),
(45, 'Lishui-híd', 'Zhangjiajie − Hunan', 'Kína', 856, 2013),
(46, 'Tacoma Narrows hidak (Észak)', 'Tacoma − Gig Harbor', 'USA', 853, 1950),
(47, 'Tacoma Narrows hidak (Kelet)', 'Tacoma − Gig Harbor', 'USA', 853, 2007),
(48, 'Askøy-híd', 'Bergen – Askøy', 'Norvégia', 850, 1992),
(49, 'Yingwuzhou híd', 'Vuhan − Hupej', 'Kína', 850, 2014),
(50, 'Ucheon − Jeokgeum', 'Dél-Csolla', 'Dél-Korea', 850, 2016);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
